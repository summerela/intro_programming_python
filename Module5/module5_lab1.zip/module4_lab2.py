# -*- coding: utf-8 -*-
#!/usr/local/src python3

import os, sys
ABSOLUTE_TSV_PATH=os.path.join( os.path.split(os.path.abspath(__name__))[0], 'data', 'fahrenheit_monthly_readings.tsv' )

def get_max_width(table, padding=2):
    #calculate the max width of the table cell
    max_width = 0
    for row in table[1:]: # skip the first recored of headers
        new_max = max([len(value) for value in row]) + padding
        # only set the new max if it's actually greater
        if new_max > max_width:
            max_width = new_max
    return max_width

def print_table(table):
    max_width = get_max_width(table)
    for row in table:
        print(*[str(i).center(max_width) for i in row], sep='|')

def calc_max_temp_average(table):
    """
    returns the mean of all the MNTH_MAX temperatures
    """
    max_temps = []
    for row in table[1:]: # skip the first recored of headers
        max_column = len(row) - 1 
        max_temps.append(int(row[max_column])) 
    print("[ AVERAGE MAX TEMP ]: {}".format(sum(max_temps)/(len(max_temps) or 1)))

def calc_min_temp(table):
    """
    returns the min of all the MNTH_MIN temperatures.
    instead of doing this manually ( like it's done below )
    you can also use the `max` module if you can figure out how
    """
    min = None
    for row in table[1:]: # skip the first recored of headers
        min_column = len(row) - 2
        new_min = int(row[min_column]) 

        if min is None: # indicator to set first min value
            min = new_min

        if new_min < min:
            min = new_min

    print("[ MIN TEMP ]: {}".format(min))

def calc_max_temp(table):
    """
    returns the max of all the MNTH_MAX temperatures
    """

    # TODO 2: write come code below here that gets the max temperature

    print("[ MAX TEMP ]: {}".format(max_temp))

def calc_median_temp(table):
    """
    returns the median of all the MNTH_MIN and MNTH_MAX temperatures
    """

    # TODO 3: write come code below here that gets the max temperature

    print("[ MEDIAN TEMP ]: {}".format(median_temp))

in_memory_table = [
]

'''
TODO 1: 
write some code below this comment that opens and reads the file located at `ABSOLUTE_TSV_PATH`. 
We want our data to be put into some kind of structure. The variable `in_memory_table` 
represents a table ( list ) where the rows will be other lists. 
In the end the `in_memory_table` structure would look
like this after it's read into memory ( of course with more than two rows ).
NOTE: the first list in the index is the header names:

[
    [
        "STATION",
        "STATION_ID",
        "ELEVATION",
        "LAT",
        "LONG",
        "DATE",
        "MNTH_MIN",
        "MNTH_MAX"
    ],
    [
        "Tukwila",
        "12345afbl",
        "10",
        "47.5463454",
        "-122.34234234",
        "2016-01-01",
        "10",
        "41"
    ],
    [
        "Tukwila",
        "12345afbl",
        "10",
        "47.5463454",
        "-122.34234234",
        "2016-02-01",
        "5",
        "35"
    ],
]
'''


print_table(in_memory_table)
calc_max_temp_average(in_memory_table)

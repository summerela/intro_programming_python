# -*- coding: utf-8 -*-
import sys
import os
# python3 has no `raw_input`, so rebind it in case this is python2
try:
	input = raw_input
except NameError:
	pass

def run_madlib(debug=False):
	input_questions = [
		'adjective',
		'noun',
		'adjective',
		'noun',
		'adverb',
		'noun, plural',
		'adjective',
		'adverb',
		'noun',
		'body part',
		'body part',
		'adverb',
		'noun',
		'body part',
		'verb',
		'adjective',
		'verb, past tense',
		'noun',
		'any grammar term, plural',
		'adjective',
		'noun',
		'adjective',
		'adverb',
		'body part',
		'noun',
		'verb for physical contact, past tense',
		'body part'
	]
	input_answers = []
	for q in input_questions:
		exit_term = 'exit'
		if debug:
			input_answers = ['filler']*len(input_questions)
			break
		response = input("[ Q ]: choose any '{}' or type '{}' to quit the program:\n".format(q, exit_term.upper()))
		if response.lower() == exit_term:
			print("{}\n\n{}\n\n".format('-'*100, "Goodbye!"))
			sys.exit(0) # graceful exit without error
		input_answers.append(response)
			
	story_template_path = os.path.join( os.path.dirname(os.path.abspath(__name__)), 'templates', 'story.txt')
	with open(story_template_path, 'r') as fsock:
		story_template = fsock.read()
		formatted_story = story_template.format(*input_answers)
		print('{}\n\n{}\n\n'.format('-'*100, formatted_story))

if __name__ == '__main__':
	if len(sys.argv) > 1 and sys.argv[1] == "debug":
		run_madlib(debug=True)
	else:
		run_madlib()





